select max(p_size)
from part;
