select count(*) from region;
