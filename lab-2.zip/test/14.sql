select min(l_tax)
from lineitem;
