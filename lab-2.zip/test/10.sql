select max(ps_availqty)
from partsupp;
