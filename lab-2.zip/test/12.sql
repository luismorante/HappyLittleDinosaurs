select distinct o_orderpriority
from orders
order by o_orderpriority;
