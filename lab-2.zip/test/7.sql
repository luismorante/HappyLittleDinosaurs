select count(*) from orders;
