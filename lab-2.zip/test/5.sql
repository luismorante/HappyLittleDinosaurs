select count(*) from part;
