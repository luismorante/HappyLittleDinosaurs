delete from region;
delete from nation;
delete from supplier;
delete from customer;
delete from part;
delete from partsupp;
delete from orders;
delete from lineitem;
